import json

# JSON 数据
body = triggerConf.get('body')

# 解析 JSON 数据
data = json.loads(body)

# 获取 action 的值
action = data.get("action")

# 根据 action 的值返回相应的结果
if action == "SIGN_FILE_RESCINDED":
    status = "已解约"
else:
    status = "解约中"

return {
    "status": status
}
